/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Send SNMP Trap to a network entity.
 *
 * New file in Quagga, added by QUAGGA snmpTRAP VERSION.
 * Contains all the essential to send a trap with params about a IP-route.
 * This is a mix between SNMP functions and custom functions by QUAGGA snmpTRAP VERSION.
 * The SNMP functions are from NET-SNMP suite, specifically from: net-snmp/apps/snmptrap.c.
 * 			Copyright 1989, 1991, 1992 by Carnegie Mellon University
 * 			All Rights Reserved.
 *			More info about copyright in README-Quagga-snmpTrap.txt.
 * In this version of Quagga, this unit is used to send a trap when a IP-route is added or deleted to the kernel.
 * For more info, read README-Quagga-snmpTrap.txt
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *
 * Copyright (C) 1997, 98, 99, 2001 Kunihiro Ishiguro
 *
 * This file is part of GNU Zebra.
 *
 * GNU Zebra is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * GNU Zebra is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GNU Zebra; see the file COPYING.  If not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.  
 */

#include <net-snmp/net-snmp-config.h>
#if HAVE_SYS_SELECT_H
#include <sys/select.h>
#endif
#if HAVE_SYS_SOCKET_H
#include <sys/socket.h>
#endif
#if HAVE_NETDB_H
#include <netdb.h>
#endif
#if HAVE_ARPA_INET_H
#include <arpa/inet.h>
#endif

#include <net-snmp/net-snmp-includes.h>

/*Global params*/
    oid             objid_enterprise[] = { 1, 3, 6, 1, 4, 1, 3, 1, 1 };
    oid             objid_sysdescr[] = { 1, 3, 6, 1, 2, 1, 1, 1, 0 };
    oid             objid_sysuptime[] = { 1, 3, 6, 1, 2, 1, 1, 3, 0 };
    oid             objid_snmptrap[] = { 1, 3, 6, 1, 6, 3, 1, 1, 4, 1, 0 };
    netsnmp_session session, *ss;
    netsnmp_pdu    *pdu;
    oid             name[MAX_OID_LEN];
    size_t          name_length;
    int             status;
    int             arg;
    int             exitval = 0;
    char *enterprise = "0", *trapGenerico = "6", *trapEspecifico = "1.3.6.1.2.1.4";
    char *trapoid = "1.3.6.1.2.1.4";			/*ip OID = iso.org.dod.internet.mgmt.mib-2.ip*/
    char	   *route_info_trap = "0.0";		/*default value: ip.21.1.13 = OID = 0.0*/
    in_addr_t      *pdu_in_addr_t;

/*PROTOTYPES*/
int snmp_input(int operation,netsnmp_session * session,int reqid, netsnmp_pdu *pdu, void *magic);
char *getNetMask(char **mask, const u_char prefixlen);
int build_and_send(char **str_ip, char **ifindex_num, char **metric_num, 
	    	char **nexthop_value, char **routeType, char **protocol, char **netmask);
int send_trap(const struct prefix_ipv4 *p, const unsigned int ifindex,const u_int32_t metric, 
		const struct in_addr *nexthop, char *routeType, char *protocol, char *version, char *dest, char	*community);


/* Dumb function needed in main function.
 * It is a legacy from Net-SNMP
 */
int
snmp_input(int operation,
           netsnmp_session * session,
           int reqid, netsnmp_pdu *pdu, void *magic)
{
    return 1;
}

/* Get the netmask format to char with dots from CIDR format
 * Params:      mask: a string with the netmask in dots format.
 *         prefixlen: the netmask in CIDR format
 * Return:      mask: a string in format xxx.xxx.xxx.xxx. 
 */
char *getNetMask(char **mask, const u_char prefixlen){
    *mask=malloc(sizeof(char)*15);
    memset( *mask, '\0', sizeof(*mask) );
    int m = prefixlen / 8;
    int aux = prefixlen;
    while(aux>=8){
	strcat(*mask,"255.");
	aux=aux-8;
    }
    if(aux!=0){
	int acum = 128, n = 0;
	char *valor= malloc(sizeof(int));
	m++;
	while(aux>0){
		n+=acum;
		acum=acum/2;
		aux--;
	}
	snprintf(valor,sizeof(int),"%d",n);
	strcat(*mask,valor);
	free(valor);
	if(m<4)
		strcat(*mask,".");
    }
    /*fill with '0'*/
    while(m<4){
	if(m==3)
		strcat(*mask,"0");
	else
		strcat(*mask,"0.");
		m++;
    }
    return *mask;
}

/* Build the snmp packet (PDU), with all variables that inform about a route.
 * Add to the pdu (global variable) the incoming and some global params.
 * Finally, the pdu is sent.
 * Params: str_ip: IP address.
 *         ifindex: interface index, the route str_ip was learned by this interface.
 *         metric_num: metric value of the route that is called str_ip.
 *         nexthop_value: the next hop if we want to achieve this route (str_ip).
 *         routeType: 
 * return: -1,  if there is an error when conf file is reading
 * 		or if there are incorrect commands.
 * return: 0 , if there is no command, so the TRAPS are disabled.
 * return: n > 0, the number of commands.
 */
int 
build_and_send(char **str_ip, char **ifindex_num, char **metric_num, 
	    char **nexthop_value, char **routeType, char **protocol, char **netmask){

    	char *dot=".";
	/*ipRoutedest = 1.3.6.1.2.1.4.21.1.1*/
	char *str_routeDest = calloc (strlen(*str_ip)+strlen("1.3.6.1.2.1.4.21.1.1")+1, sizeof(char));
	strcat(strcat(strcat(str_routeDest,"1.3.6.1.2.1.4.21.1.1"),dot),*str_ip);
	/*ipRouteIfIndex = 1.3.6.1.2.1.4.21.1.2*/
	char *str_ifindex = calloc(strlen(*str_ip)+strlen("1.3.6.1.2.1.4.21.1.2")+1, sizeof(char));
	strcat(strcat(strcat(str_ifindex,"1.3.6.1.2.1.4.21.1.2"),dot),*str_ip);
	/*ipRouteMetric1 = 1.3.6.1.2.1.4.21.1.3*/
	char *str_metric = calloc(strlen(*str_ip)+strlen("1.3.6.1.2.1.4.21.1.3")+1, sizeof(char));
	strcat(strcat(strcat(str_metric,"1.3.6.1.2.1.4.21.1.3"),dot), *str_ip);
	/*ipRouteNextHop = 1.3.6.1.2.1.4.21.1.7*/
	char *str_nexthop = calloc(strlen(*str_ip)+strlen("1.3.6.1.2.1.4.21.1.7")+1, sizeof(char));
	strcat(strcat(strcat(str_nexthop,"1.3.6.1.2.1.4.21.1.7"),dot),*str_ip);
	/*ipRouteType = 1.3.6.1.2.1.4.21.1.8*/
	char *str_routeType = calloc(strlen(*str_ip)+strlen("1.3.6.1.2.1.4.21.1.8")+1, sizeof(char));
	strcat(strcat(strcat(str_routeType,"1.3.6.1.2.1.4.21.1.8"),dot),*str_ip);
	/*ipRouteProto = 1.3.6.1.2.1.4.21.1.9*/
	char *str_proto = calloc(strlen(*str_ip)+strlen("1.3.6.1.2.1.4.21.1.9")+1, sizeof(char));
	strcat(strcat(strcat(str_proto,"1.3.6.1.2.1.4.21.1.9"),dot),*str_ip);
	/*ipRouteMask = 1.3.6.1.2.1.4.21.1.11*/
	char *str_netmask = calloc(strlen(*str_ip)+strlen("1.3.6.1.2.1.4.21.1.11")+1, sizeof(char));
	strcat(strcat(strcat(str_netmask,"1.3.6.1.2.1.4.21.1.11"),dot),*str_ip);
	/*ipRouteInfo = 1.3.6.1.2.1.4.21.1.13*/
	char *str_info = calloc(strlen(*str_ip)+strlen("1.3.6.1.2.1.4.21.1.13")+1, sizeof(char));
	strcat(strcat(strcat(str_info,"1.3.6.1.2.1.4.21.1.13"),dot),*str_ip);
	
	char* oid_type_value[]={str_routeDest, "a", *str_ip, str_ifindex, "i", *ifindex_num, 
				str_metric, "i", *metric_num, str_nexthop,"a", *nexthop_value, 
				str_routeType, "i", *routeType, str_proto,"i", *protocol, 
				str_netmask, "a", *netmask, str_info, "o", route_info_trap};
	int size_oid_type_value = sizeof(oid_type_value)/sizeof(int);
	
						/*adding values to the TRAP*/
	arg=0;
        while (arg < size_oid_type_value) {
        arg = arg + 3;
        if (arg > size_oid_type_value ) {
            fprintf(stderr, "%s: Missing type/value for variable\n",oid_type_value[arg - 3]);
            SOCK_CLEANUP;
            //exit(1);
	    return 1;
        }
        name_length = MAX_OID_LEN;
        if (!snmp_parse_oid(oid_type_value[arg - 3], name, &name_length)) {
            snmp_perror(oid_type_value[arg - 3]);
            SOCK_CLEANUP;
            //exit(1);
	     return 1;
        }
        if (snmp_add_var
            (pdu, name, name_length, oid_type_value[arg - 2][0],oid_type_value[arg - 1]) != 0) {
            snmp_perror(oid_type_value[arg - 3]);
            SOCK_CLEANUP;
            //exit(1);
	     return 1;
        }
    }
    /*SEND AND CLOSE THE TRAP*/
    
    status = snmp_send(ss, pdu) == 0;
    if (status) {
        snmp_sess_perror("snmptrap", ss);
        snmp_free_pdu(pdu);
        exitval = 1;
    } 
    free(str_routeDest);
    free(str_ifindex);
    free(str_metric);
    free(str_nexthop);
    free(str_routeType);
    free(str_proto);
    free(str_netmask);
    free(str_info);

    snmp_close(ss);
    snmp_shutdown("snmpapp");
    SOCK_CLEANUP;

    return exitval;
}

/* Main function to send the TRAP.
 * Receives the params, makes the datagram (PDU) and sends it.
 * 
 * Params: p: IP address of the new route/net learned.
 *         ifindex: interface index, the route/net was learned by this interface.
 *         metric: metric value of the route.
 *         nexthop: the next hop if we want to achieve this route/net.
 *         routeType: The route was added or deleted.
 *         protocol: Which routing protocol has learned the route/net.
 *         version: SNMP version.
 *         dest: Destination of the TRAP. Usually is the manager station.
 *         community: Name of the SNMP community.
 * return: -1,  if there is some error.
 * return: 0 , everything is ok.
 */
int
send_trap(const struct prefix_ipv4 *p, const unsigned int ifindex, const u_int32_t metric, 
	    const struct in_addr *nexthop, char *routeType, char *protocol, char *version, char *dest, char *community){
   
    /*format IP address to char*/
    char *str_ip = malloc(sizeof(char)*15);
    char *aux = inet_ntoa(p->prefix);
    strcpy(str_ip,aux);
    /*format nexthop address to char*/
    char *nexthop_value = malloc(sizeof(char)*15);
    aux = inet_ntoa(*nexthop);
    strcpy(nexthop_value,aux);

    /*format ifindex to char*/
    char *ifindex_num = malloc(sizeof(unsigned int));
    sprintf(ifindex_num,"%d",ifindex);
    /*format metric to char*/
    char *metric_num = malloc(sizeof(int)*2);
    sprintf(metric_num,"%d",metric);

    /*format CIDR netmask to char with dots*/
    char *netmask = NULL;
    getNetMask(&netmask, p->prefixlen);

    putenv(strdup("POSIXLY_CORRECT=1"));
    /*initialize session*/
    snmp_sess_init(&session);
    init_snmp("snmpapp");
    /*add version name*/
    if(!strcmp(version,"v1"))
    	session.version = SNMP_VERSION_1;
    else
	session.version = SNMP_VERSION_2c;
    /*add community name*/
    session.community = (unsigned char *)community;
    session.community_len = strlen(community);
    /*add destinity name*/
    session.peername = dest;

    SOCK_STARTUP;

    session.callback = snmp_input;
    session.callback_magic = NULL;

    /*
     * setup the local engineID which may be for either or both of the
     * contextEngineID and/or the securityEngineID.
     */
    setup_engineID(NULL, NULL);

    /* if we don't have a contextEngineID set via command line
       arguments, use our internal engineID as the context. */
    if (session.contextEngineIDLen == 0 ||
        session.contextEngineID == NULL) {
        session.contextEngineID =
            snmpv3_generate_engineID(&session.contextEngineIDLen);
    }

    ss = snmp_add(&session,
                  netsnmp_transport_open_client("snmptrap", session.peername),
                  NULL, NULL);
    if (ss == NULL) {
        /*
         * diagnose netsnmp_transport_open_client and snmp_add errors with
         * the input netsnmp_session pointer
         */
        snmp_sess_perror("snmptrap", &session);
	fprintf(stderr, "Failed to create session trap PDU\n");
        SOCK_CLEANUP;
	return 1;
        //exit(1);
    }
	/*START: version 1*/							
    if(!strcmp(version,"v1")){	
        pdu = snmp_pdu_create(SNMP_MSG_TRAP);
        if ( !pdu ) {
            fprintf(stderr, "Failed to create trap PDU\n");
            SOCK_CLEANUP;
	    return 1;
            //exit(1);
        }
        pdu_in_addr_t = (in_addr_t *) pdu->agent_addr;

	/*enterprise section */
	if (enterprise[0] == 0) {
        	pdu->enterprise = (oid *) malloc(sizeof(objid_enterprise));
        	memcpy(pdu->enterprise, objid_enterprise,sizeof(objid_enterprise));
        	pdu->enterprise_length = sizeof(objid_enterprise) / sizeof(oid);
	}
	else{
            name_length = MAX_OID_LEN;
            if (!snmp_parse_oid(enterprise, name, &name_length)) {
                snmp_perror(enterprise);
                SOCK_CLEANUP;
                //exit(1);
		fprintf(stderr, "Failed to create trap PDU enterprise section\n");
		return 1;
            }
            pdu->enterprise = (oid *) malloc(name_length * sizeof(oid));
            memcpy(pdu->enterprise, name, name_length * sizeof(oid));
            pdu->enterprise_length = name_length;
        }
	/*agent section*/
        *pdu_in_addr_t = get_myaddr();
	/*generic trap*/
        pdu->trap_type = atoi(trapGenerico);
	/*specific trap (generic must be = 6)*/
        pdu->specific_type = atoi(trapEspecifico);
	/*uptime*/
        pdu->time = get_uptime();				
            
    }	/*END: version 1*/	
	/*START: version 2*/
    else{
	long sysuptime;
        char csysuptime[20];

        pdu = snmp_pdu_create(SNMP_MSG_TRAP2);
        if ( !pdu ) {
            fprintf(stderr, "Failed to create notification PDU\n");
            SOCK_CLEANUP;
            //exit(1);
	    return 1;
        }
        /*uptime*/
        sysuptime = get_uptime();
        sprintf(csysuptime, "%ld", sysuptime);
        snmp_add_var(pdu, objid_sysuptime,sizeof(objid_sysuptime) / sizeof(oid), 't', csysuptime);
        
        if (snmp_add_var(pdu, objid_snmptrap, sizeof(objid_snmptrap) / sizeof(oid),'o', trapoid) != 0) {
            snmp_perror(trapoid);
            SOCK_CLEANUP;
            //exit(1);
	    return 1;
        }
    }	/*END: version 2*/

	/*ADD VARIABLES TO THE TRAP AND SEND IT*/
	int exit_value = build_and_send(&str_ip, &ifindex_num, &metric_num, &nexthop_value, &routeType, &protocol, &netmask);
	free(str_ip);
	free(ifindex_num);
	free(metric_num);
	free(nexthop_value);
	free(netmask);
    return exit_value;
}

