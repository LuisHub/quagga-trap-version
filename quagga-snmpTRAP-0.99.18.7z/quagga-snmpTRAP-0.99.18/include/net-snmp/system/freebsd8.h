/* freebsd8 is a superset of freebsd4 */
#include "freebsd4.h"
#define freebsd4 freebsd4
#define freebsd5 freebsd5
