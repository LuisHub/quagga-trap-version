Quagga-snmpTrap-Version 0.99.18

This is a normal Quagga but it has a new modification. It is able to send an alert (TRAP), when Zebra adds/deletes a route in kernel.

All of this is a part of a senior year project raised to increase the capabilities of Quagga routing suite. At the same time, it pretends the suite can be understood with Simple Network Management Protocol, whose initials are SNMP, which is very extended and it is very used by networks managers. All without using proxy servers or proxy devices.

The project consist in to give to Quagga the capability of sending alerts through SNMP, whenever the main daemon, Zebra, adds or removes routes to or from the device kernel where it is installed. These alerts are sent using a SNMP packet called TRAP, so network managers can get these automatically in the destination that they have configured.

For the project, it was used the last version of Quagga, 0.99.18, although the changes are very extensibles and duly documented, so if future versions of oficial Quagga don´t include these changes, the same improvement can be made without problems.

Copyright of Quagga-snmpTrap is the same of original Quagga routing suite. See README.

This file describes the changes in Quagga TRAP Version, from the original Quagga-0.99.18 source code.
When a new Quagga is released, this version will also release in: http://code.google.com/p/quagga-trap-version/

Changes in Quagga-snmpTrap-Version:
- Added "include" folder in base directory. Inside, there are snmp headers from NET-SNMP suite, specifically from net-snmp/include.
- Added two files in "/lib" folder: the snmp library "libsnmp" and the sender function: "sendsnmptrap.c"
- New config file: "sendsnmptrap.conf", this file must be in same place as the others config files. Its name must be "sendsnmptrap.conf".
  If you want to change that name, go to the source code: line 914 in zebra_rib.c
- Modified files: "/zebra/zebra_rib.c", "/zebra/Makefile.in", "README".
You can see the specific changes at the bottom.

Contact: http://code.google.com/p/quagga-trap-version/
Reporting-bugs: http://code.google.com/p/quagga-trap-version/


COPYRIGHT OF NET-SNMP:
/******************************************************************
	Copyright 1989, 1991, 1992 by Carnegie Mellon University

                      All Rights Reserved

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation, and that the name of CMU not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.

CMU DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
CMU BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.

More info in http://www.net-snmp.org
******************************************************************/

COPYRIGHT OF QUAGGA:
/* Routing Information Base.
 * Copyright (C) 1997, 98, 99, 2001 Kunihiro Ishiguro
 *
 * This file is part of GNU Zebra.
 *
 * GNU Zebra is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * GNU Zebra is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GNU Zebra; see the file COPYING.  If not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.  
 */
More info in http://www.quagga.net
/********************************************************************/
/********************************************************************/
HOW TO INSTALL:
This software can be installed the same way as original Quagga. See INSTALL file and follow the instructions.
After the installation, Quagga configure script says that you have to add a new user (quagga), but I recomend you have to do some things more:
# adduser quagga
# cd /usr/local/etc/
# cp zebra.conf.sample zebra.conf
# cp ripd.conf.sample ripd.conf
# cp ospfd.conf.sample ospfd.conf
# cp bgpd.conf.sample bgpd.conf
# cp /usr/local/lib/libzebra.* /lib/
So it is, change the cofig files name and put lib files in the correct place.
/********************************************************************/
/********************************************************************/
HOW TO USE:
This software is used like the original Quagga, see the official documentation of Quagga in: http://www.quagga.net.
summary, first of all, you have to give some permissions to quagga user every time you execute some daemon:
# chown quagga /var/run
# chown quagga /var/lib/snmp
# chown quagga /usr/local/etc

So I recomend you use the script called "quagga-snmpTRAP.sh"

IMPORTANT:
There is a new config file: "sendsnmptrap.conf" that you can find in the root of source code.
This file must be in same place as the others config files. Its name must be "sendsnmptrap.conf".
If you want to change that name, go to line 914 in zebra_rib.c

Now you can run the software, for example:
#zebra -d
#ripd -d
If you want to run RIP (or any others daemons), you first run zebra, and then the daemon/s.

/********************************************************************/
/********************************************************************/
Changes in: "/zebra/zebra_rib.c":
- Line: 44, added a include command.
- Line: 55, new global variables.
- Line: 923, new function to read the config file.
- Line: 983, modification to send the TRAP with new route.
- line: 1059, modification to send the TRAP with deleted route.
- Line: 3062, modification to free params.
- Line: 3074. modification to read the config file.

Changes in: "/zebra/Makefile.in":
- Line: 153, add line to include the new folder and the new lib.
- Line: 310, add libsnmp.
- Line: 311, add libsnmp.

Changes in: "README":
- Line: 9, add line.
